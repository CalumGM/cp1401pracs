name = input("input: ")
